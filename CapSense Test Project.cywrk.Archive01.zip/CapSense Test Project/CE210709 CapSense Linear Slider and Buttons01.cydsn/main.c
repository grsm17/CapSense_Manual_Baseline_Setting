/******************************************************************************
* File Name: main.c
*******************************************************************************
*   Included Headers
*******************************************************************************/
#include "CapSense.h"
#include <project.h>
#include <stdio.h>

uint8 flag = 0; //falg used to check if read from flash is required
char ch;//char used to store inputted uart data


/* this project can funciton in one of 2 methods
if dummy sensor is defined and factory cal commented out, the design uses the principal of a dummy sensor
that can not be touched in real life to set the baseline values of the actual sensor.
using this method the baseline should track for temperature and humidity over time, but also allow press on power up to be detectable

the other method is enabled when dummy sensor is commented out and factory cal is defined.
in this method, the user presses F the first time when the board is in a known state and not being touched, normally on the production line. this could be replaced with a delay, switch input etc.
this stores the known non touch baseline in sflash and sets a flag value.
on subsequent power cycles, the flag is checked, and before starting normal capsense operation these baseline values are loaded back in to the array. 
this should also allow button press on power up to be detected.

do not enable both defines at the same time!
*/

#define DUMMY_SENSOR
//#define FACTORY_CAL


/* function declaration to enable full printf usage*/
int _write(int file, char *ptr, int len)
{
    int i;
    file = file;
    for (i = 0; i < len; i++)
    {
        UART_UartPutChar(*ptr++);
    }
    return len;
}

//function to set the LEDs on or off based on widget state
void LEDControl(void);


/* Start of main application function*/
int main()
{	
    
    /* Enable global interrupts. */
    CyGlobalIntEnable; 
    
    #ifdef FACTORY_CAL
    
    //variables for storing/reading/writing from flash
    uint8_t buf[CY_SFLASH_SIZEOF_USERROW];
    uint8_t *mySFlash;
    mySFlash = (uint8_t*)CY_SFLASH_USERBASE;
    
    if(mySFlash[0] == 0xaa)
    {
        
        flag=1;
    }
    #endif
    
    #ifdef DUMMY_SENSOR   
    flag=1;//set the flag to enter the same loop we want to use
    #endif    
     
    //start the uart for printf purposes
    UART_Start();
    CyDelay(100);
    
    /* I2C for tuner use to help monitor real time values*/
    EZI2C_Start();
    EZI2C_EzI2CSetBuffer1(sizeof(CapSense_dsRam),sizeof(CapSense_dsRam),(uint8 *)&CapSense_dsRam);

    if(flag==1)
    {
        
        
        CapSense_Start(); //start the capsense block 
        
        CapSense_InitializeAllBaselines();//take the first sample to set up the arrays
        
        
        #ifdef FACTORY_CAL
            
        printf("flag is 1, so scan CapSense and run tuner forever\r\n");
        
        //copy the stored values from sflash in to the arrays
        CapSense_dsRam.snsList.btn0[0].bsln[0] = mySFlash[1] <<8 | mySFlash[2];
        CapSense_dsRam.snsList.btn1[0].bsln[0] = mySFlash[3] <<8 | mySFlash[4];
        CapSense_dsRam.snsList.btn2[0].bsln[0] = mySFlash[5] <<8 | mySFlash[6];
        CapSense_dsRam.snsList.btn3[0].bsln[0] = mySFlash[7] <<8 | mySFlash[8];
        CapSense_dsRam.snsList.btn4[0].bsln[0] = mySFlash[9] <<8 | mySFlash[10];
        #endif
        
        #ifdef DUMMY_SENSOR
        //set all the baseline values to be the same as the middle sensor value
            //in this case we have 5 sensors so use sensor 2 value
            
        //send them out over printf for debug use
           
        printf("but0 baseline = %d \r\n", CapSense_dsRam.snsList.btn0[0].bsln[0]);
        printf("but1 baseline = %d \r\n", CapSense_dsRam.snsList.btn1[0].bsln[0]);
        printf("but2 baseline = %d \r\n", CapSense_dsRam.snsList.btn2[0].bsln[0]);
        printf("but3 baseline = %d \r\n", CapSense_dsRam.snsList.btn3[0].bsln[0]);
        printf("but4 baseline = %d \r\n", CapSense_dsRam.snsList.btn4[0].bsln[0]);
        
        
        //printf the idac values for checking purposes
        printf("but0 idac = %d \r\n", CapSense_dsRam.snsList.btn0[0].idacComp[0]);
        printf("but1 idac = %d \r\n", CapSense_dsRam.snsList.btn1[0].idacComp[0]);
        printf("but2 idac = %d \r\n", CapSense_dsRam.snsList.btn2[0].idacComp[0]);
        printf("but3 idac = %d \r\n", CapSense_dsRam.snsList.btn3[0].idacComp[0]);
        printf("but4 idac = %d \r\n", CapSense_dsRam.snsList.btn4[0].idacComp[0]);
        
        //set the baselines to all be the same as sensor 2
        CapSense_dsRam.snsList.btn0[0].bsln[0] = CapSense_dsRam.snsList.btn2[0].bsln[0];
        CapSense_dsRam.snsList.btn1[0].bsln[0] = CapSense_dsRam.snsList.btn2[0].bsln[0];
     
        CapSense_dsRam.snsList.btn3[0].bsln[0] = CapSense_dsRam.snsList.btn2[0].bsln[0];
        CapSense_dsRam.snsList.btn4[0].bsln[0] = CapSense_dsRam.snsList.btn2[0].bsln[0];  
        #endif
        
        CyDelay(100);
        
        for(;;)
        {  
            /* Initiate new scan only if the CapSense block is idle */
            if(CapSense_NOT_BUSY == CapSense_IsBusy())
            {
                //run the tuner function over i2c
                CapSense_RunTuner();

                /* Scan widget configured by CSDSetupWidget API */
                CapSense_ScanAllWidgets();
       
                //process all the data to determine status
                CapSense_ProcessAllWidgets();
                
                //local function for LED manipulation based on widget status
                LEDControl();
            }//end if busy
        }//end of for loop
        
    }//end of if flag1
    #ifdef FACTORY_CAL
    else if (flag==0)
    {
        while(1)
        {
            printf("Enter F to start factory calibration\r\n");
            
            while(UART_SpiUartGetRxBufferSize() == 0);
            ch = UART_UartGetChar();
                
            if(ch == 0x46) //Capital F in hex
            {  

                printf("flag is 0 so store Cap Baseline values in to flash\r\n");
            
                CapSense_Start();//start the CapSense block
    
                CyDelay(500);
	     
                CapSense_InitializeAllBaselines();//take the first reading to set the original baseline values
                
                //send them out over printf for debug use
                printf("but0 baseline = %d \r\n", CapSense_dsRam.snsList.btn0[0].bsln[0]);
                printf("but1 baseline = %d \r\n", CapSense_dsRam.snsList.btn1[0].bsln[0]);
                printf("but2 baseline = %d \r\n", CapSense_dsRam.snsList.btn2[0].bsln[0]);
                printf("but3 baseline = %d \r\n", CapSense_dsRam.snsList.btn3[0].bsln[0]);
                printf("but4 baseline = %d \r\n", CapSense_dsRam.snsList.btn4[0].bsln[0]);
                
                CyDelay(500);
                
                uint32 retval;//to check flash write
            
                buf[0] = 0xaa; //set the flag bit  
            
                //write the high and low byte of 16bit baseline value to buf
                buf[1] = CapSense_dsRam.snsList.btn0[0].bsln[0] >>8;
                buf[2] = CapSense_dsRam.snsList.btn0[0].bsln[0] & 0xFF;

                buf[3] = CapSense_dsRam.snsList.btn1[0].bsln[0] >>8;
                buf[4] = CapSense_dsRam.snsList.btn1[0].bsln[0] & 0xFF;

                buf[5] = CapSense_dsRam.snsList.btn2[0].bsln[0] >>8;
                buf[6] = CapSense_dsRam.snsList.btn2[0].bsln[0] & 0xFF;

                buf[7] = CapSense_dsRam.snsList.btn3[0].bsln[0] >>8;
                buf[8] = CapSense_dsRam.snsList.btn3[0].bsln[0] & 0xFF;

                buf[9] = CapSense_dsRam.snsList.btn4[0].bsln[0] >>8;
                buf[10] = CapSense_dsRam.snsList.btn4[0].bsln[0] & 0xFF;
                
                //write the buf array to sflash
                retval = CySysSFlashWriteUserRow(0, buf);
                
                printf("Sflash result %lu \r\n", retval);
                break;
            }
            else
            {
                
            }
        }//end while1
    }//end else flag=0
    #endif
}


void LEDControl(void)
{
if(CapSense_IsWidgetActive(0))
        {
            LED0_Write(0);   
        }
        else
        {
            LED0_Write(1);  
        }
        if(CapSense_IsWidgetActive(1))
        {
            LED1_Write(0);   
        }
        else
        {
            LED1_Write(1);  
        }
        if(CapSense_IsWidgetActive(2))
        {
            LED2_Write(0);   
        }
        else
        {
            LED2_Write(1);  
        }
        if(CapSense_IsWidgetActive(3))
        {
            LED3_Write(0);   
        }
        else
        {
            LED3_Write(1);  
        }
        if(CapSense_IsWidgetActive(4))
        {
            LED4_Write(0);   
        }
        else
        {
            LED4_Write(1);  
        }
}
/* [] END OF FILE */
